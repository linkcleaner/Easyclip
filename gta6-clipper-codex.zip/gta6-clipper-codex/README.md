# GTA Stream Clipper — Codex Skill

This is a Codex-native adaptation of the supplied GTA6 Clipper project. Codex itself selects highlights from a local transcript; Python/FFmpeg performs downloading, transcription, framing, captioning and rendering. No Claude CLI and no Anthropic API are required.

## Windows quick start

1. Extract this ZIP to a normal folder, e.g. `C:\Users\YOU\Tools\gta6-clipper-codex`.
2. Open that folder in Codex.
3. Ask Codex to read `SKILL.md` and run `scripts/setup.ps1`.
4. Give Codex a public stream/VOD link and ask it to make 3 clips. It will run `prepare`, inspect `codex_input.json`, write `codex_picks.json`, then run `render`.

If Codex does not show the skill, restart Codex. User-level skills are loaded from `~/.agents/skills`; project-level skills can live under `.agents/skills`. This package itself can be opened as a project folder; to install globally, copy the folder into `%USERPROFILE%\.agents\skills\gta6-clipper-codex`.

## Dependencies

- Python 3.11+
- FFmpeg + ffprobe
- yt-dlp and a JS runtime (Deno or Node) for YouTube extraction
- Python packages installed by setup: faster-whisper, opencv-python-headless, Pillow, NumPy, yt-dlp

The first Whisper run downloads the selected model. A few GB of free disk space is recommended. The tool processes media locally; network access is needed to fetch stream media and model files.

## Run manually

```powershell
.\.venv\Scripts\python.exe .\scripts\codex_pipeline.py prepare "https://www.youtube.com/watch?v=..." --clips 3
# Codex reads codex_input.json and writes codex_picks.json
.\.venv\Scripts\python.exe .\scripts\codex_pipeline.py render --input "C:\...\codex_input.json"
```

Mac/Linux:
```bash
.venv/bin/python scripts/codex_pipeline.py prepare "URL" --clips 3
.venv/bin/python scripts/codex_pipeline.py render --input "/path/codex_input.json"
```

## Notes

- The original Claude-specific moment selection has been removed. Codex performs selection through the active skill context.
- This version does not publish to TikTok, Instagram or YouTube. It exports local files only.
- Only process streams you are allowed to download and republish. Platform terms and copyright still apply.
