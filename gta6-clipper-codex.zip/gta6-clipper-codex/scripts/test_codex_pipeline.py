import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from clipper import moments

def test_snap():
    words=[{"s":i,"e":i+0.4,"w":"word." if i%5==4 else "word"} for i in range(0,80)]
    cfg={"min_duration":15,"max_duration":60}
    m={"start":10.2,"end":32.1}
    got=moments.snap(m,words,cfg)
    assert got and 15 <= got["end"]-got["start"] <= 60

def test_dedupe():
    xs=[{"start":0,"end":20,"score":80},{"start":2,"end":22,"score":70},{"start":40,"end":60,"score":65}]
    assert len(moments.dedupe(xs))==2

if __name__=="__main__":
    test_snap(); test_dedupe(); print("Codex pipeline unit checks passed")
