#!/usr/bin/env python3
"""Two-stage local clip pipeline controlled by Codex's current model context."""
import argparse, datetime, json, os, re, shutil, sys, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
# Ensure console scripts installed in the active virtual environment are discoverable.
VENV_BIN = str(Path(sys.executable).resolve().parent)
os.environ["PATH"] = VENV_BIN + os.pathsep + os.environ.get("PATH", "")
sys.path.insert(0, str(HERE))
from clipper import config, fetch, find, layout, moments, render, scan
from clipper.util import Timer, hhmmss, log, minutes, probe, require, set_tag, slugify


def seconds(stamp):
    total = 0.0
    for part in stamp.strip().split(":"):
        total = total * 60 + float(part)
    return total


def stream_key(url):
    return re.sub(r"[^A-Za-z0-9_-]", "_", url.split("://")[-1])[-80:]


def prepare(opts):
    for tool, hint in (("yt-dlp", "Run the skill setup to install yt-dlp in its virtual environment."),
                       ("ffmpeg", "Install FFmpeg and add it to PATH."),
                       ("ffprobe", "Install FFmpeg (ffprobe is included).")):
        require(tool, hint)
    cfg = config.load({"clips_per_stream": opts.clips, "min_duration": opts.min_duration,
                       "max_duration": opts.max_duration})
    config.HOME.mkdir(parents=True, exist_ok=True)
    work = config.HOME / "work" / stream_key(opts.url)
    work.mkdir(parents=True, exist_ok=True)
    args = fetch.base_args(opts.url, opts.cookies)
    timer = Timer()
    with timer.stage("metadata"):
        info = fetch.info(opts.url, args, work)
    set_tag(info.get("name", "stream")[:18])
    if info.get("live_status") == "is_live":
        log("Stream is live; analysing the portion available so far.", "warn")
    with timer.stage("download audio"):
        audio = fetch.audio(opts.url, args, work)
    duration = probe(audio)["duration"]
    lo, hi = 0.0, duration
    if opts.section:
        a, _, b = opts.section.lstrip("*").partition("-")
        lo = seconds(a); hi = min(seconds(b), duration) if b else duration
    if hi <= lo:
        raise RuntimeError("Invalid section range: end must be after start.")
    pick_dir = work if not opts.section else work / f"part_{int(lo)}_{int(hi)}"
    pick_dir.mkdir(parents=True, exist_ok=True)
    with timer.stage("transcription"):
        heard = scan.transcript(audio, lo, hi, pick_dir, cfg)
        loud = scan.relative(scan.loudness(audio, work))
        chat = scan.chat_rate(opts.url, args, work, cfg, info)
        clipped = find.viewer_clips(info)
    lines = moments._lines(heard["words"], loud, chat or [], cfg, clipped)
    if not lines:
        raise RuntimeError("No speech was detected; cannot prepare highlight selection.")
    transcript = [{"time": round(t, 1), "text": text} for t, text in lines]
    packet = {
        "schema_version": 1,
        "stream": {"name": info.get("name") or "stream", "title": info.get("title") or "Untitled stream",
                   "url": opts.url, "duration_seconds": round(duration), "extractor": info.get("extractor_key"),
                   "live_status": info.get("live_status")},
        "analysis": {"section_start": lo, "section_end": hi, "requested_clips": opts.clips,
                     "minimum_seconds": cfg["min_duration"], "maximum_seconds": cfg["max_duration"],
                     "minimum_score": cfg["min_score"], "language": heard.get("language"),
                     "word_count": len(heard["words"]), "transcript_line_count": len(transcript)},
        "transcript": transcript,
        "selection_instructions": "Select only strong standalone moments. start/end are absolute seconds in the source stream. Output a JSON array to codex_picks.json next to this file. See SKILL.md for exact schema and editorial rules."
    }
    packet_path = pick_dir / "codex_input.json"
    packet_path.write_text(json.dumps(packet, ensure_ascii=False, indent=2), encoding="utf-8")
    # Preserve paths/settings in a private manifest; Codex only needs the input packet.
    manifest = {"url": opts.url, "workdir": str(work), "pick_dir": str(pick_dir), "audio": str(audio),
                "info": info, "section_start": lo, "section_end": hi, "cookies": opts.cookies,
                "clips": opts.clips, "timer_seconds": timer.total()}
    (pick_dir / "codex_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\nCODEX_INPUT=" + str(packet_path))
    print("CODEX_PICKS=" + str(pick_dir / "codex_picks.json"))
    print(f"Prepared {minutes(hi-lo)} of audio; {len(heard['words'])} recognised words in {len(transcript)} transcript lines.")
    set_tag("")


def render_picks(opts):
    input_path = Path(opts.input).expanduser().resolve()
    pick_dir = input_path.parent
    manifest_path = pick_dir / "codex_manifest.json"
    picks_path = pick_dir / "codex_picks.json"
    if not manifest_path.exists(): raise RuntimeError(f"Missing pipeline manifest: {manifest_path}")
    if not picks_path.exists(): raise RuntimeError(f"Codex must first create: {picks_path}")
    packet = json.loads(input_path.read_text(encoding="utf-8"))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    raw = json.loads(picks_path.read_text(encoding="utf-8"))
    if not isinstance(raw, list): raise RuntimeError("codex_picks.json must contain a JSON array")
    cfg = config.load({"clips_per_stream": manifest["clips"]})
    words = json.loads((pick_dir / "scan.json").read_text(encoding="utf-8"))["words"]
    clipped = find.viewer_clips(manifest["info"])
    valid=[]
    for m in raw:
        if not isinstance(m, dict): continue
        try:
            score = max(1, min(100, round(float(m.get("score", 0)))))
            m["score"] = score
            if score < cfg["min_score"]: continue
            if not str(m.get("hook_text", "")).strip(): continue
            if not str(m.get("kind", "")).strip(): m["kind"] = "highlight"
            if not isinstance(m.get("hashtags"), list): m["hashtags"] = []
            m["hashtags"] = [str(x) for x in m["hashtags"][:5]]
            m["caption"] = str(m.get("caption", ""))[:150]
            m["reason"] = str(m.get("reason", ""))[:500]
            snapped = moments.snap(m, words, cfg)
            if snapped:
                valid.append(moments.cover(snapped, clipped, cfg))
        except (TypeError, ValueError, KeyError):
            continue
    valid = moments.dedupe(valid)[:manifest["clips"]]
    if not valid:
        print(f"No valid highlight scored {cfg['min_score']} or higher. No video files were rendered.")
        return
    url, audio = manifest["url"], Path(manifest["audio"])
    args = fetch.base_args(url, manifest.get("cookies"))
    info = manifest["info"]
    stream = {"name": info.get("name") or "stream", "title": info.get("title") or "Untitled stream", "url": url}
    outdir = config.HOME / datetime.date.today().isoformat() / f"{slugify(stream['name'],24)}__{slugify(stream['title'],40)}"
    outdir.mkdir(parents=True, exist_ok=True)
    ready=[]; made=[]; known={}
    for i,m in enumerate(valid,1):
        try: ready.append(render.prepare(url,args,audio,m,i,pick_dir,cfg,packet.get("analysis",{}).get("language")))
        except Exception as exc: log(f"[clip {i}] prepare failed: {str(exc)[:300]}","err")
    pin=cfg["cams"].get(stream["name"].lower())
    if pin and ready:
        wide=ready[0]["info"]["width"]/1920
        known={"cams":[[v*wide for v in pin]],"settled":True}
    else:
        for p in ready: render.learn(p,cfg,known)
        layout.settle(known)
    for p in ready:
        try: made.append(render.finish(p,outdir,pick_dir,cfg,known))
        except Exception as exc: log(f"[clip {p['index']}] render failed: {str(exc)[:300]}","err")
    summary=f"{minutes(manifest['section_end']-manifest['section_start'])} analysed -> {len(made)} clip(s)"
    render.post_sheet(outdir,stream,made,summary)
    (outdir/"report.json").write_text(json.dumps({"stream":stream,"clips":len(made),"summary":summary,
        "pipeline":"Codex-assisted local selection; FFmpeg render"},ensure_ascii=False,indent=2),encoding="utf-8")
    if made and not opts.keep_audio: audio.unlink(missing_ok=True)
    print(f"\nOUTPUT_DIR={outdir}")
    print(f"Rendered {len(made)} clip(s). Files: " + ", ".join(c["file"] for c in made))


def discover(opts):
    cfg = config.load()
    config.HOME.mkdir(parents=True, exist_ok=True)
    found = find.find(cfg, limit=opts.streams)
    if not found:
        print("No matching streams found. Add entries to ~/gta6-clips/streamers.txt or provide a direct URL.")
        return
    for i, item in enumerate(found, 1):
        print(f"{i}. {item.get('name','?')} | {item.get('title','')} | {item.get('views',0)} views | {item.get('url','')}")


def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest="command",required=True)
    d=sub.add_parser("discover",help="list currently discoverable streams from YouTube and the watchlist")
    d.add_argument("--streams",type=int,default=5)
    a=sub.add_parser("prepare",help="download audio and create a Codex highlight-selection packet")
    a.add_argument("url"); a.add_argument("--clips",type=int,default=3); a.add_argument("--cookies",choices=["chrome","safari","firefox","brave","edge"])
    a.add_argument("--section"); a.add_argument("--min",dest="min_duration",type=int,default=None); a.add_argument("--max",dest="max_duration",type=int,default=None)
    a.add_argument("--keep-audio",action="store_true")
    b=sub.add_parser("render",help="render clips from Codex's codex_picks.json")
    b.add_argument("--input",required=True); b.add_argument("--keep-audio",action="store_true")
    opts=p.parse_args()
    try:
        if opts.command=="prepare": prepare(opts)
        elif opts.command=="discover": discover(opts)
        else: render_picks(opts)
    except KeyboardInterrupt: print("\nCancelled.",file=sys.stderr); sys.exit(130)
    except Exception as exc: print(f"ERROR: {exc}",file=sys.stderr); sys.exit(1)

if __name__=="__main__": main()
