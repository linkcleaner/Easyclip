#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENV="$ROOT/.venv"
command -v ffmpeg >/dev/null || { echo "FFmpeg missing. Install it with your OS package manager."; exit 1; }
command -v ffprobe >/dev/null || { echo "ffprobe missing (normally included with FFmpeg)."; exit 1; }
command -v deno >/dev/null || command -v node >/dev/null || { echo "YouTube extraction needs Deno or Node. Install Deno from https://deno.com/runtime."; exit 1; }
command -v python3 >/dev/null || { echo "Python 3.11+ is required."; exit 1; }
python3 -m venv "$VENV"
"$VENV/bin/python" -m pip install --upgrade pip
"$VENV/bin/python" -m pip install "faster-whisper" "opencv-python-headless<5" pillow numpy "yt-dlp[default]"
mkdir -p "$HOME/gta6-clips"
[ -f "$HOME/gta6-clips/streamers.txt" ] || cp "$ROOT/streamers.txt" "$HOME/gta6-clips/streamers.txt"
echo "Setup complete. The first run downloads the Whisper model."
echo "Try: $VENV/bin/python $ROOT/scripts/codex_pipeline.py prepare 'STREAM_URL' --clips 3"
