"""Settings. Defaults below; override any of them in ~/gta6-clips/config.json."""

import json
import os
import sys
from pathlib import Path

HOME = Path.home() / "gta6-clips"
WINDOWS = os.name == "nt"
MAC = sys.platform == "darwin"


def _first(*paths):
    """The first font file that exists here (Windows, Mac, Linux paths), else the first one."""
    return next((p for p in paths if p and os.path.exists(p)), paths[0])


_WINFONTS = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
HOOK_FONT = _first(
    os.path.join(_WINFONTS, "arialbd.ttf"),
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/usr/share/fonts/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
)

DEFAULTS = {
    # --- finding streams ---
    "game": "Grand Theft Auto VI",   # Twitch category name (official API only)
    "search": "GTA 6",               # YouTube search words
    "title_words": ["gta"],          # a watchlist VOD must have one of these in its title
    "max_age_hours": 36,             # ignore watchlist VODs older than this

    # --- download ---
    "max_height": 1080,

    # --- listening to the stream ---
    "scan_model": "base",            # pass over the whole stream (what Claude reads); "tiny" = faster, rougher
    "caption_model": "base",         # careful pass over each chosen clip (the captions)
    "language": None,                # None = detect, or "en"
    "scan_block_minutes": 20,        # audio is decoded in blocks, so 10-hour streams fit in memory
    "loud_db": 6.0,                  # louder than the last 2 minutes by this much = a spike
    "chat": True,                    # YouTube replays: count chat messages per 5 s
    "chat_timeout": 420,

    # --- picking moments ---
    "clips_per_stream": 3,
    "min_duration": 15,
    "max_duration": 60,
    "chunk_minutes": 12,             # transcript grouping size for Codex review packets
    "min_score": 60,                # a moment scored below this is not clipped, even if it is the best one

    # --- framing ---
    "layout": "auto",                # auto | stream | face | fit
    "output_width": 1080,
    "output_height": 1920,
    "cam_height": 760,               # stream layout: height of the facecam panel on top
    "cam_zoom": 1.5,                 # most the facecam is enlarged; a cam too small to fill the panel at this
                                     # is shown smaller on a blurred copy of itself (99 = always fill the panel)
    "cams": {},                    # facecam pinned by hand: {"channel name in lowercase": [x, y, w, h]},
                                     # in pixels of a 1920x1080 frame; beats the automatic finder
    "fit_aspect": 1.7778,            # fit layout: 1.7778 keeps the whole 16:9 frame (cams sit on edges)
    "track_smoothing": 5,

    # --- hook (the title bar) ---
    "hook_font_file": HOOK_FONT,
    "hook_font_size": 54,
    "hook_y": 0.09,
    "hook_margin_x": 150,

    # --- captions ---
    "font": "Arial Black",
    "font_size": 82,
    "words_per_group": 4,
    "uppercase": True,
    "text_color": "FFFFFF",
    "highlight_color": "FFE13B",
    "outline_width": 6,
    "caption_y": 0.72,
    "word_pop": True,

    # --- encoding ---
    "encoder": "libx264",            # --fast: h264_videotoolbox (Mac) or h264_nvenc (NVIDIA card)
    "crf": 20,
    "preset": "medium",
    "audio_bitrate": "192k",
    "loudnorm": True,
}


def load(overrides=None):
    cfg = dict(DEFAULTS)
    path = HOME / "config.json"
    if path.exists():
        try:
            cfg.update(json.loads(path.read_text()))
        except json.JSONDecodeError as exc:
            raise SystemExit(f"{path} is not valid JSON: {exc}")
    for key, value in (overrides or {}).items():
        if value is not None:
            cfg[key] = value
    return cfg
