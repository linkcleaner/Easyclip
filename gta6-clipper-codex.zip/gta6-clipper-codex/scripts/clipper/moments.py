"""Timestamp helpers shared by the Codex-assisted clip pipeline.

Codex reads codex_input.json and writes codex_picks.json. This module validates,
snaps and de-duplicates those editorial choices; it does not call an LLM/API.
"""
import numpy as np


def _lines(words, loud, chat, cfg, clipped=(), line_seconds=8):
    lines, cur, start = [], [], None
    chat_base = float(np.median([c for c in chat if c > 0])) if chat and any(chat) else 0

    def flush(t0, t1, text):
        tags = []
        views = max((v for a, b, v in clipped if a < t1 and b > t0), default=0)
        if views:
            tags.append(f"[CLIPPED {views} views]")
        if len(loud):
            a, b = int(t0), max(int(t0) + 1, int(np.ceil(t1)))
            peak = float(np.max(loud[a:b])) if a < len(loud) else 0
            if peak >= cfg["loud_db"]:
                tags.append(f"[LOUD +{peak:.0f}dB]")
        if chat_base:
            a, b = int(t0 // 5), int(t1 // 5) + 2
            seg = chat[a:b]
            if seg:
                ratio = max(seg) / chat_base
                if ratio >= 2.5:
                    tags.append(f"[CHAT x{ratio:.0f}]")
        lines.append((t0, (" ".join(tags) + " " if tags else "") + text))

    for w in words:
        if start is None:
            start = w["s"]
        cur.append(w["w"])
        if w["e"] - start >= line_seconds:
            flush(start, w["e"], " ".join(cur))
            cur, start = [], None
    if cur:
        flush(start, words[-1]["e"], " ".join(cur))
    return lines


def snap(moment, words, cfg):
    """Snap rough Codex timestamps to recognized word edges and enforce duration bounds."""
    try:
        start, end = float(moment["start"]), float(moment["end"])
    except (KeyError, TypeError, ValueError):
        return None
    if end <= start:
        return None
    near = [w for w in words if w["s"] >= start - 1.5]
    if not near:
        return None
    first = min(near, key=lambda w: abs(w["s"] - start))
    inside = [w for w in words if first["s"] <= w["s"] and w["e"] <= end + 1.5]
    if not inside:
        return None
    last = min(inside, key=lambda w: abs(w["e"] - end))
    lo, hi = int(cfg["min_duration"]), int(cfg["max_duration"])
    if last["e"] - first["s"] > hi:
        fit = [w for w in inside if w["e"] - first["s"] <= hi]
        if not fit:
            return None
        ends = [w for w in fit if w["w"].rstrip().endswith((".", "!", "?"))]
        last = ends[-1] if ends else fit[-1]
    if last["e"] - first["s"] < lo:
        after = [w for w in words if w["e"] > last["e"] and w["e"] - first["s"] <= hi]
        reach = [w for w in after if w["e"] - first["s"] >= lo]
        if reach:
            last = reach[0]
        elif after:
            last = after[-1]
        if last["e"] - first["s"] < lo:
            return None
    moment["start"] = round(max(0.0, first["s"] - 0.6), 2)
    moment["end"] = round(min(last["e"] + 0.6, moment["start"] + hi), 2)
    return moment


def cover(moment, clipped, cfg):
    cut = [c for c in clipped if moment["start"] <= c[0] < moment["end"] < c[1]]
    if cut:
        end = max(cut, key=lambda c: c[2])[1] + 1.0
        moment["end"] = round(min(end, moment["start"] + cfg["max_duration"]), 2)
    return moment


def views(moment, clipped):
    return max((v for a, b, v in clipped
                if min(moment["end"], b) - max(moment["start"], a) >= 0.5 * (b - a)), default=0)


def dedupe(candidates):
    kept = []
    for m in sorted(candidates, key=lambda x: -float(x.get("score", 0))):
        span = m["end"] - m["start"]
        if all(min(m["end"], k["end"]) - max(m["start"], k["start"])
               <= 0.3 * min(span, k["end"] - k["start"]) for k in kept):
            kept.append(m)
    return kept
