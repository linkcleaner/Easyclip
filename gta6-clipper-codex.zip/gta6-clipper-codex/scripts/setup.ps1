$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Venv = Join-Path $Root ".venv"
Write-Host "GTA Stream Clipper setup (Windows)" -ForegroundColor Cyan
foreach ($tool in @("ffmpeg", "ffprobe")) {
  if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
    Write-Host "Missing $tool. Install FFmpeg (winget install -e --id Gyan.FFmpeg) and yt-dlp (py -m pip install yt-dlp), then reopen PowerShell." -ForegroundColor Yellow
    exit 1
  }
}
if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw "Python launcher 'py' not found. Install Python 3.11+ from python.org." }
if (-not (Get-Command deno -ErrorAction SilentlyContinue) -and -not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host "YouTube extraction needs Deno or Node. Install Deno: winget install -e --id DenoLand.Deno" -ForegroundColor Yellow
  exit 1
}
if (-not (Test-Path $Venv)) { py -3.11 -m venv $Venv }
$Py = Join-Path $Venv "Scripts\python.exe"
& $Py -m pip install --upgrade pip
& $Py -m pip install "faster-whisper" "opencv-python-headless<5" pillow numpy "yt-dlp[default]"
if ($LASTEXITCODE -ne 0) { throw "Python dependency installation failed." }
$HomeClips = Join-Path $HOME "gta6-clips"
New-Item -ItemType Directory -Force -Path $HomeClips | Out-Null
$Watch = Join-Path $HomeClips "streamers.txt"
if (-not (Test-Path $Watch)) { Copy-Item (Join-Path $Root "streamers.txt") $Watch }
Write-Host "Setup complete. First Whisper run downloads its model files." -ForegroundColor Green
Write-Host "Try: .\.venv\Scripts\python.exe .\scripts\codex_pipeline.py prepare 'STREAM_URL' --clips 3"
